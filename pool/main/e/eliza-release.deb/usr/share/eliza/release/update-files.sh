#!/bin/bash
set -e

BASE="/usr/share/eliza/release"
FILES=(issue issue.net lsb-release os-release motd)

for f in "${FILES[@]}"; do
    DEFAULT="$BASE/$f"
    TARGET="/etc/$f"

    # Overwrite only if missing or still matches old default
    if [ ! -f "$TARGET" ] || cmp -s "$DEFAULT" "$TARGET"; then
        cp "$DEFAULT" "$TARGET"
    fi
done